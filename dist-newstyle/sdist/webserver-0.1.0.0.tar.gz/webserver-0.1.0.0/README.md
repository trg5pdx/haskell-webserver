# webserver

This is a basic key-value webserver implemented in the Haskell programming 
language. This server is meant for no serious use cases and is just an
exercise for me to work more in Haskell, and with functional programming
in general.
